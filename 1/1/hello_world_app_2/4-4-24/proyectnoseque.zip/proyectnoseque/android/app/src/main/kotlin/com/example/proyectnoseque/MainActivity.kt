package com.example.proyectnoseque

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
